<h1>Better Canvas</h1>

Contact ksucpea@gmail.com for suggestions or reporting issues

<h2>Update 5.0.1</h3>

- Improved assignments list (uses mutation observer now)

- Better custom url check

- GPA Calculator overhaul

- See dark mode customizations in real time

- Dark mode improvements

<h2>Links</h2>

[Chrome version](https://chrome.google.com/webstore/detail/better-canvas/cndibmoanboadcifjkjbdpjgfedanolh)

[Firefox version](https://addons.mozilla.org/addon/better-canvas/)
